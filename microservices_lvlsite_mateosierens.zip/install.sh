sudo snap install docker
sudo snap start docker
sudo docker-compose -f docker-compose-dev.yml up --build
