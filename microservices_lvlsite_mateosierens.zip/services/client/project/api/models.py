# services/client/project/api/models.py


from sqlalchemy.sql import func
from project import db

