# services/client/project/tests/test_client.py

import json
import unittest

from project import db
# from project.api.models import Referee, Division, Status, Match
from project.tests.base import BaseTestCase


class TestClientService(BaseTestCase):
    """Test for the Client Service."""
    pass

if __name__ == '__main__':
    unittest.main()
